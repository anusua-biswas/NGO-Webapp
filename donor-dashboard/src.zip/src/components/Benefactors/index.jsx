import BenefactorPage from "./BenefactorPage";

export default BenefactorPage;
